// State
let currentTheme = 'Sci-Fi';
let stream = null;

// DOM Elements
const webcamVideo = document.getElementById('webcam');
const resultImage = document.getElementById('resultImage');
const captureCanvas = document.getElementById('captureCanvas');
const clickPhotoBtn = document.getElementById('clickPhotoBtn');
const retakeBtn = document.getElementById('retakeBtn');
const loadingOverlay = document.getElementById('loadingOverlay');
const loadingStatusText = document.getElementById('loadingStatusText');
const cameraPlaceholder = document.getElementById('cameraPlaceholder');
const statusBanner = document.getElementById('statusBanner');
const themeButtons = document.querySelectorAll('.theme-btn');

// Initialize Camera
async function initCamera() {
  try {
    cameraPlaceholder.classList.add('hidden');
    webcamVideo.classList.remove('hidden');
    resultImage.classList.add('hidden');
    retakeBtn.classList.add('hidden');
    clickPhotoBtn.classList.remove('hidden');

    if (stream) {
      stream.getTracks().forEach(track => track.stop());
    }

    stream = await navigator.mediaDevices.getUserMedia({
      video: {
        width: { ideal: 1024 },
        height: { ideal: 1024 },
        facingMode: 'user'
      },
      audio: false
    });
    webcamVideo.srcObject = stream;
  } catch (err) {
    console.error('Camera access error:', err);
    cameraPlaceholder.classList.remove('hidden');
    cameraPlaceholder.innerHTML = '<span>⚠️ Camera access denied or unavailable.<br><small>Please allow webcam access in browser.</small></span>';
    showStatus('Please enable camera permissions to take a photo.', 'error');
  }
}

// Setup Theme Buttons
themeButtons.forEach(btn => {
  btn.addEventListener('click', () => {
    themeButtons.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    currentTheme = btn.dataset.theme;
  });
});

// Capture Photo as Square Base64 Image
function captureSquareFrame() {
  const videoWidth = webcamVideo.videoWidth;
  const videoHeight = webcamVideo.videoHeight;

  if (!videoWidth || !videoHeight) {
    throw new Error('Webcam is not ready yet');
  }

  // Crop square from the center of video
  const minDim = Math.min(videoWidth, videoHeight);
  const startX = (videoWidth - minDim) / 2;
  const startY = (videoHeight - minDim) / 2;

  // Standard output dimension
  const targetDim = 768;
  captureCanvas.width = targetDim;
  captureCanvas.height = targetDim;
  const ctx = captureCanvas.getContext('2d');

  // Since webcam is mirrored on display, mirror it horizontally when saving so it matches user's perspective
  ctx.translate(targetDim, 0);
  ctx.scale(-1, 1);

  ctx.drawImage(
    webcamVideo,
    startX, startY, minDim, minDim,
    0, 0, targetDim, targetDim
  );

  return captureCanvas.toDataURL('image/jpeg', 0.92);
}

// Show/Hide Helpers
function showLoading(text) {
  loadingStatusText.textContent = text || 'Processing...';
  loadingOverlay.classList.remove('hidden');
  clickPhotoBtn.disabled = true;
  retakeBtn.disabled = true;
}

function hideLoading() {
  loadingOverlay.classList.add('hidden');
  clickPhotoBtn.disabled = false;
  retakeBtn.disabled = false;
}

function showStatus(message, type = 'info', link = null) {
  statusBanner.className = `status-banner ${type}`;
  if (link) {
    statusBanner.innerHTML = `${message}<br><a href="${link}" target="_blank" rel="noopener">Open in Google Drive ↗</a>`;
  } else {
    statusBanner.textContent = message;
  }
  statusBanner.classList.remove('hidden');
}

function hideStatus() {
  statusBanner.classList.add('hidden');
}

// Click Photo Handler
clickPhotoBtn.addEventListener('click', async () => {
  hideStatus();
  let base64Photo = '';
  try {
    base64Photo = captureSquareFrame();
  } catch (e) {
    showStatus('Failed to capture frame: ' + e.message, 'error');
    return;
  }

  showLoading(`Reimagining your photo with AI (${currentTheme})...`);

  try {
    const response = await fetch('/api/reimagine', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        image: base64Photo,
        theme: currentTheme
      })
    });

    const data = await response.json();

    if (!response.ok || !data.success) {
      throw new Error(data.error || 'Failed to generate image');
    }

    // Display generated result in place of camera
    resultImage.src = data.imageUrl;
    resultImage.classList.remove('hidden');
    webcamVideo.classList.add('hidden');
    clickPhotoBtn.classList.add('hidden');
    retakeBtn.classList.remove('hidden');

    if (data.driveFileUrl) {
      showStatus('✨ Reimagined & Saved to Google Drive!', 'success', data.driveFileUrl);
    } else if (data.driveError) {
      showStatus(`✨ Reimagined! (Drive Note: ${data.driveError})`, 'info');
    } else {
      showStatus('✨ Successfully reimagined with AI!', 'success');
    }
  } catch (err) {
    console.error('Generation error:', err);
    showStatus(`Error: ${err.message}`, 'error');
  } finally {
    hideLoading();
  }
});

// Retake Button
retakeBtn.addEventListener('click', () => {
  hideStatus();
  initCamera();
});

// Start camera on page load
window.addEventListener('DOMContentLoaded', initCamera);

