import os
import sys

# Ensure local directory is in sys.path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from ai_generator import reimagine_image
from drive_storage import upload_image_to_drive

app = Flask(__name__, static_folder='.')
CORS(app)

@app.route('/')
def serve_index():
    return send_from_directory('.', 'index.html')

@app.route('/<path:path>')
def serve_static(path):
    return send_from_directory('.', path)

@app.route('/api/health', methods=['GET'])
def health():
    return jsonify({"status": "healthy", "service": "CGC SQUARE Kiosk"})

@app.route('/api/reimagine', methods=['POST'])
def handle_reimagine():
    try:
        data = request.get_json(force=True)
        if not data or 'image' not in data:
            return jsonify({"success": False, "error": "No image data received"}), 400

        image_data = data.get('image')
        theme = data.get('theme', 'Sci-Fi')

        # 1. AI Image generation
        reimagined_image_b64, ai_info = reimagine_image(image_data, theme)

        # 2. Upload to Google Drive (with local storage fallback)
        drive_res = upload_image_to_drive(reimagined_image_b64, filename_prefix=f"cgc_{theme.lower()}")

        response_payload = {
            "success": True,
            "theme": theme,
            "imageUrl": reimagined_image_b64,
            "aiMethod": ai_info,
            "driveUploaded": drive_res.get("uploaded_to_drive", False)
        }

        if drive_res.get("web_link"):
            response_payload["driveFileUrl"] = drive_res.get("web_link")
        elif drive_res.get("note"):
            response_payload["driveError"] = drive_res.get("note")
        elif drive_res.get("error"):
            response_payload["driveError"] = drive_res.get("error")

        return jsonify(response_payload)

    except Exception as e:
        print(f"[Server Error]: {e}")
        return jsonify({"success": False, "error": str(e)}), 500

if __name__ == '__main__':
    port = int(os.environ.get("PORT", 5000))
    print("=================================================")
    print(f"CGC SQUARE Kiosk Server running on http://127.0.0.1:{port}")
    print("=================================================")
    app.run(host='0.0.0.0', port=port, debug=False)
