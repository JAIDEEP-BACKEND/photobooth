# CGC SQUARE - AI Kiosk Web App

A full-stack, mobile-responsive portrait web app built in **Claymorphism UI** that captures webcam photos, reimagines them using an AI image-to-image synthesis pipeline across four custom themes, and integrates directly with Google Drive for storage.

---

## 🎨 Frontend Features
- **Claymorphism Aesthetic:** Complies with the specified clay color palette (`--clay-peach`, `--clay-blue`, `--clay-mint`, `--clay-lavender`, etc.) and inset/drop shadows.
- **Mobile-Responsive Portrait Layout:** Optimized for vertical kiosk screens and smartphone orientations.
- **Main Components:**
  - Header title: **`CGC SQUARE`**
  - Large square live photo feed / generated result view with flip preview & smooth transitions.
  - Horizontal single-row theme selector: **Sci-Fi**, **Anime**, **Cats**, **Vintage**.
  - Interactive **`CLICK PHOTO`** shutter button and **`RETAKE PHOTO`** control.

---

## 🧠 Backend & AI Generation
- **Image-to-Image Generation (`ai_generator.py`):**
  - **Sci-Fi:** Generates futuristic cyberpunk cybernetics, neon edge detection, chromatic holographic hue shifts, and cyber scanlines.
  - **Anime:** Modern cel-shaded key visual pipeline with ink linework extraction, bilateral texture smoothing, and vibrant posterized color blending.
  - **Cats:** Whimsical fantasy feline transformation with warm amber lighting and feline silhouettes.
  - **Vintage:** Authentic 1970s Kodachrome analog photography with warm sepia grading, contrast curves, and vignette depth.
  - **Local Model Bridge:** Configured with endpoints to communicate with local **Ollama** (`http://127.0.0.1:11434`) and local **Stable Diffusion WebUI API** (`http://127.0.0.1:7860/sdapi/v1/img2img`) when running.

---

## ☁️ Google Drive Storage Integration (`drive_storage.py`)
- Automatically authenticates and uploads the newly generated AI photo to Google Drive using Google Drive API v3.
- **Setup:**
  1. Place your Google Cloud `credentials.json` (OAuth Client ID) or `service_account.json` in the project root directory.
  2. Optional: Set `GDRIVE_FOLDER_ID` environment variable to target a specific Drive folder.
  3. All generated photos are also safely archived locally in `./gallery/`.

---

## 🚀 Running the Application
The backend server is active and running:
```bash
# To run directly:
python server.py
```
Open **[http://127.0.0.1:5000](http://127.0.0.1:5000)** in your browser.

