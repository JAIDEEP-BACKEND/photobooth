import os
import io
import time
import base64
from datetime import datetime

# Google Drive API Client Libraries
try:
    from googleapiclient.discovery import build
    from googleapiclient.http import MediaIoBaseUpload
    from google.oauth2 import service_account
    from google.oauth2.credentials import Credentials
    from google_auth_oauthlib.flow import InstalledAppFlow
    from google.auth.transport.requests import Request
    GOOGLE_LIBS_AVAILABLE = True
except ImportError:
    GOOGLE_LIBS_AVAILABLE = False

SCOPES = ['https://www.googleapis.com/auth/drive.file']
CREDENTIALS_FILE = os.path.join(os.path.dirname(__file__), "credentials.json")
TOKEN_FILE = os.path.join(os.path.dirname(__file__), "token.json")
SERVICE_ACCOUNT_FILE = os.path.join(os.path.dirname(__file__), "service_account.json")
GDRIVE_FOLDER_ID = os.environ.get("GDRIVE_FOLDER_ID", None)

def get_drive_service():
    """
    Authenticate and return Google Drive v3 service instance.
    Supports Service Account or OAuth 2.0 User credentials.
    """
    if not GOOGLE_LIBS_AVAILABLE:
        return None, "Google API libraries not installed"

    creds = None

    # Option A: Service account JSON file
    if os.path.exists(SERVICE_ACCOUNT_FILE):
        try:
            creds = service_account.Credentials.from_service_account_file(
                SERVICE_ACCOUNT_FILE, scopes=SCOPES
            )
            return build('drive', 'v3', credentials=creds), None
        except Exception as e:
            print(f"[Drive] Service account error: {e}")

    # Option B: OAuth2 User Token
    if os.path.exists(TOKEN_FILE):
        try:
            creds = Credentials.from_authorized_user_file(TOKEN_FILE, SCOPES)
        except Exception as e:
            print(f"[Drive] Token error: {e}")

    # If no valid token exists or is expired
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            try:
                creds.refresh(Request())
            except Exception as e:
                print(f"[Drive] Refresh token error: {e}")
                creds = None

        # Try interactive OAuth flow if credentials.json is present
        if not creds and os.path.exists(CREDENTIALS_FILE):
            try:
                flow = InstalledAppFlow.from_client_secrets_file(CREDENTIALS_FILE, SCOPES)
                creds = flow.run_local_server(port=0)
                with open(TOKEN_FILE, 'w') as token:
                    token.write(creds.to_json())
            except Exception as e:
                return None, f"OAuth error: {e}"

    if creds:
        return build('drive', 'v3', credentials=creds), None

    return None, "Google Drive credentials not configured (credentials.json or service_account.json)"

def upload_image_to_drive(base64_data, filename_prefix="reimagined_photo"):
    """
    Decodes base64 data, uploads to Google Drive, and returns webViewLink.
    Falls back gracefully if Drive credentials are pending configuration.
    """
    # Clean base64
    if "," in base64_data:
        base64_data = base64_data.split(",", 1)[1]
    
    image_bytes = base64.b64decode(base64_data)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    file_name = f"{filename_prefix}_{timestamp}.jpg"

    # Save a local backup copy in a local 'gallery' directory as well
    gallery_dir = os.path.join(os.path.dirname(__file__), "gallery")
    os.makedirs(gallery_dir, exist_ok=True)
    local_path = os.path.join(gallery_dir, file_name)
    with open(local_path, "wb") as f:
        f.write(image_bytes)

    service, err = get_drive_service()
    if not service:
        # Save locally and explain status
        return {
            "success": True,
            "uploaded_to_drive": False,
            "local_path": local_path,
            "note": f"Saved locally in ./gallery/{file_name}. Drive upload requires credentials.json ({err})"
        }

    try:
        file_metadata = {
            'name': file_name,
            'mimeType': 'image/jpeg'
        }
        if GDRIVE_FOLDER_ID:
            file_metadata['parents'] = [GDRIVE_FOLDER_ID]

        media = MediaIoBaseUpload(io.BytesIO(image_bytes), mimetype='image/jpeg', resumable=True)
        uploaded_file = service.files().create(
            body=file_metadata,
            media_body=media,
            fields='id, name, webViewLink, webContentLink'
        ).execute()

        # Try to make publicly readable for sharing if requested
        try:
            service.permissions().create(
                fileId=uploaded_file.get('id'),
                body={'type': 'anyone', 'role': 'reader'}
            ).execute()
        except Exception:
            pass

        return {
            "success": True,
            "uploaded_to_drive": True,
            "file_id": uploaded_file.get('id'),
            "web_link": uploaded_file.get('webViewLink'),
            "local_path": local_path
        }
    except Exception as e:
        print(f"[Drive Upload Error]: {e}")
        return {
            "success": True,
            "uploaded_to_drive": False,
            "local_path": local_path,
            "error": str(e)
        }

