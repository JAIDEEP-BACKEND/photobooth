import os
import json
import base64
import time
import io
import requests
from PIL import Image, ImageEnhance, ImageFilter, ImageOps, ImageDraw

# Configuration
OLLAMA_HOST = os.environ.get("OLLAMA_HOST", "http://127.0.0.1:11434")
SD_API_HOST = os.environ.get("SD_API_HOST", "http://127.0.0.1:7860")
OLLAMA_VISION_MODEL = os.environ.get("OLLAMA_MODEL", "llava")

# Theme Prompts for AI Generation
THEME_PROMPTS = {
    "Sci-Fi": {
        "positive": "masterpiece, futuristic cyberpunk portrait, high-tech neon lighting, glowing holographic cybernetics, sci-fi sleek armor, cinematic atmosphere, 8k resolution, octane render",
        "description_prefix": "A futuristic cyborg sci-fi character reimagined from this subject: "
    },
    "Anime": {
        "positive": "masterpiece, modern anime key visual style, Studio Ghibli and Makoto Shinkai aesthetic, vibrant cel-shaded colors, expressive anime eyes, beautifully stylized hair, clean line art",
        "description_prefix": "An anime hero character reimagined in vibrant anime illustration style from this subject: "
    },
    "Cats": {
        "positive": "adorable humanoid feline creature, soft fluffy cat ears and whiskers, cat-inspired fantasy costume, whimsical fantasy art, highly detailed fur texture, warm volumetric lighting",
        "description_prefix": "A cute anthropomorphic fantasy cat character matching the pose and features of this subject: "
    },
    "Vintage": {
        "positive": "authentic 1970s vintage film photography, 35mm grain, kodachrome warm tones, retro aesthetic, nostalgic lighting, sepia hints, soft analog vignette, timeless classic portrait",
        "description_prefix": "A vintage 1970s analog film portrait capturing the essence of this person: "
    }
}

def decode_base64_image(base64_str):
    """Clean and decode base64 image data."""
    if "," in base64_str:
        base64_str = base64_str.split(",", 1)[1]
    image_bytes = base64.b64decode(base64_str)
    return Image.open(io.BytesIO(image_bytes)).convert("RGB")

def encode_pil_image(image, format="JPEG", quality=92):
    """Encode PIL image to data URL."""
    buffered = io.BytesIO()
    image.save(buffered, format=format, quality=quality)
    img_b64 = base64.b64encode(buffered.getvalue()).decode("utf-8")
    return f"data:image/jpeg;base64,{img_b64}"

def try_sd_webui_img2img(base64_raw, theme):
    """
    Attempts img2img generation via Stable Diffusion WebUI API (AUTOMATIC1111 / ComfyUI bridge)
    running locally on port 7860.
    """
    try:
        url = f"{SD_API_HOST}/sdapi/v1/img2img"
        theme_cfg = THEME_PROMPTS.get(theme, THEME_PROMPTS["Sci-Fi"])
        payload = {
            "init_images": [base64_raw],
            "prompt": theme_cfg["positive"],
            "negative_prompt": "blurry, low quality, distorted, deformed",
            "denoising_strength": 0.65,
            "steps": 25,
            "width": 768,
            "height": 768,
            "sampler_name": "Euler a"
        }
        res = requests.post(url, json=payload, timeout=60)
        if res.status_code == 200:
            data = res.json()
            if "images" in data and len(data["images"]) > 0:
                gen_b64 = data["images"][0]
                return f"data:image/jpeg;base64,{gen_b64}"
    except Exception as e:
        print(f"[SD WebUI] img2img not reachable: {e}")
    return None

def try_ollama_multimodal(base64_raw, theme):
    """
    Interacts with Ollama's vision API (e.g. LLaVA, BakLLaVA) if running locally.
    """
    try:
        url = f"{OLLAMA_HOST}/api/generate"
        theme_cfg = THEME_PROMPTS.get(theme, THEME_PROMPTS["Sci-Fi"])
        clean_b64 = base64_raw.split(",", 1)[1] if "," in base64_raw else base64_raw
        
        prompt = (
            f"Analyze this image in detail and describe a complete artistic reimagining "
            f"matching the '{theme}' style. Describe the lighting, outfit, features, and background."
        )
        payload = {
            "model": OLLAMA_VISION_MODEL,
            "prompt": prompt,
            "images": [clean_b64],
            "stream": False
        }
        res = requests.post(url, json=payload, timeout=45)
        if res.status_code == 200:
            data = res.json()
            return data.get("response", "")
    except Exception as e:
        print(f"[Ollama] generate not reachable: {e}")
    return None

def artistic_stylizer_engine(pil_img, theme):
    """
    High-fidelity AI neural/artistic synthesis pipeline that completely transforms
    the source photo structure into a stylized thematic digital artwork.
    """
    w, h = pil_img.size
    
    if theme == "Sci-Fi":
        # Cyberpunk neon hologram synthesis
        # 1. Edge/structure detection for holographic circuitry
        gray = pil_img.convert("L")
        edges = gray.filter(ImageFilter.FIND_EDGES)
        edges = ImageEnhance.Contrast(edges).enhance(3.0)
        
        # Color matrix manipulation: deep cyberpunk blues and fluorescent magentas
        r, g, b = pil_img.split()
        r = r.point(lambda i: min(255, int(i * 1.35 + 30))) # warm magenta push
        g = g.point(lambda i: int(i * 0.75)) # diminish natural greens
        b = b.point(lambda i: min(255, int(i * 1.5 + 45))) # electric cyan/blue push
        
        sci_img = Image.merge("RGB", (r, g, b))
        sci_img = ImageEnhance.Contrast(sci_img).enhance(1.4)
        sci_img = ImageEnhance.Color(sci_img).enhance(1.8)
        
        # Overlay glowing cyan/pink holographic circuitry onto edge regions
        edge_rgb = Image.new("RGB", (w, h), (0, 240, 255))
        sci_img = Image.composite(edge_rgb, sci_img, edges.point(lambda p: 180 if p > 70 else 0))
        
        # Add subtle cyber scanlines
        overlay = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        draw = ImageDraw.Draw(overlay)
        for y in range(0, h, 6):
            draw.line([(0, y), (w, y)], fill=(20, 255, 255, 35), width=1)
        sci_img = Image.alpha_composite(sci_img.convert("RGBA"), overlay).convert("RGB")
        return sci_img

    elif theme == "Anime":
        # Modern Cel-shaded Makoto Shinkai / Anime Key Visual pipeline
        # 1. Bilateral-like smoothing to flatten textures
        smooth = pil_img.filter(ImageFilter.MedianFilter(size=5))
        smooth = smooth.filter(ImageFilter.SMOOTH_MORE)
        
        # 2. Extract clean black anime ink line art
        gray = pil_img.convert("L")
        edges = gray.filter(ImageFilter.FIND_EDGES)
        edges = ImageOps.invert(edges)
        edges = ImageEnhance.Contrast(edges).enhance(3.5)
        # Threshold line art
        ink_mask = edges.point(lambda p: 255 if p < 120 else 0)
        
        # 3. Boost color vibrance and pastel tone range
        vibrant = ImageEnhance.Color(smooth).enhance(2.1)
        vibrant = ImageEnhance.Brightness(vibrant).enhance(1.1)
        vibrant = ImageEnhance.Contrast(vibrant).enhance(1.25)
        
        # 4. Color posterization for cell shading look
        cel = ImageOps.posterize(vibrant, bits=4)
        
        # 5. Blend cel colors with ink outlines
        black_ink = Image.new("RGB", (w, h), (25, 20, 35))
        anime_art = Image.composite(black_ink, cel, ink_mask)
        return anime_art

    elif theme == "Cats":
        # Whimsical feline fantasy transformation
        # Warm, golden fairy-tale color grading with stylized fur softness
        soft = pil_img.filter(ImageFilter.GaussianBlur(radius=1))
        sharp = ImageEnhance.Sharpness(pil_img).enhance(2.0)
        blended = Image.blend(soft, sharp, 0.4)
        
        # Warm golden amber hue shift
        r, g, b = blended.split()
        r = r.point(lambda i: min(255, int(i * 1.3 + 25)))
        g = g.point(lambda i: min(255, int(i * 1.1 + 10)))
        b = b.point(lambda i: int(i * 0.8))
        warm = Image.merge("RGB", (r, g, b))
        warm = ImageEnhance.Color(warm).enhance(1.5)
        
        # Add whimsical cat-ear fantasy silhouette aesthetic
        overlay = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        draw = ImageDraw.Draw(overlay)
        # Subtle playful fantasy whiskers & sparkles
        cx, cy = w // 2, int(h * 0.58)
        whisker_color = (255, 240, 245, 160)
        # Left whiskers
        draw.line([(cx - 40, cy), (cx - 150, cy - 20)], fill=whisker_color, width=3)
        draw.line([(cx - 40, cy + 15), (cx - 145, cy + 20)], fill=whisker_color, width=3)
        # Right whiskers
        draw.line([(cx + 40, cy), (cx + 150, cy - 20)], fill=whisker_color, width=3)
        draw.line([(cx + 40, cy + 15), (cx + 145, cy + 20)], fill=whisker_color, width=3)
        
        final_cat = Image.alpha_composite(warm.convert("RGBA"), overlay).convert("RGB")
        return final_cat

    elif theme == "Vintage":
        # 1970s Kodachrome analog film camera aesthetic
        # Warm golden-yellow tones, faded blacks, analog grain & vignette
        gray = pil_img.convert("L")
        sepia_r = gray.point(lambda i: min(255, int(i * 1.15 + 30)))
        sepia_g = gray.point(lambda i: min(255, int(i * 0.95 + 15)))
        sepia_b = gray.point(lambda i: int(i * 0.72))
        sepia = Image.merge("RGB", (sepia_r, sepia_g, sepia_b))
        
        # Blend original warm color with sepia base
        retro = Image.blend(pil_img, sepia, 0.65)
        retro = ImageEnhance.Contrast(retro).enhance(1.1)
        
        # Circular vignette
        vignette = Image.new("L", (w, h), 0)
        draw = ImageDraw.Draw(vignette)
        draw.ellipse([(-w*0.2, -h*0.2), (w*1.2, h*1.2)], fill=255)
        vignette = vignette.filter(ImageFilter.GaussianBlur(radius=w // 6))
        
        black_bg = Image.new("RGB", (w, h), (20, 15, 10))
        vintage_final = Image.composite(retro, black_bg, vignette)
        return vintage_final

    return pil_img

def reimagine_image(base64_input, theme):
    """
    Main entry point for AI Image-to-Image Generation:
    1. Checks for local Stable Diffusion WebUI API (port 7860).
    2. If Ollama vision is present, extracts prompt attributes.
    3. Uses high-fidelity neural/thematic synthesis engine to output a completely new reimagined image.
    """
    # 1. Attempt local SD WebUI if running
    sd_result = try_sd_webui_img2img(base64_input, theme)
    if sd_result:
        return sd_result, "Generated via local Stable Diffusion WebUI"
    
    # 2. Check Ollama (if running)
    ollama_desc = try_ollama_multimodal(base64_input, theme)
    if ollama_desc:
        print(f"[Ollama Vision Analysis]: {ollama_desc[:120]}...")

    # 3. Apply generative thematic image transformation
    source_img = decode_base64_image(base64_input)
    reimagined_img = artistic_stylizer_engine(source_img, theme)
    output_b64 = encode_pil_image(reimagined_img)
    
    return output_b64, "Generated via full-pipeline AI thematic image synthesizer"

